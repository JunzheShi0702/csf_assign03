TODO: Junzhe Shi & Albert Wang
MS1: Read the project and get familiar with MS1-3 and the main purpose of this assignment.

MS1:
Junzhe: input read, input parse, hardcoded stdout
Albert: input validation

TODO (for MS3): best cache report
